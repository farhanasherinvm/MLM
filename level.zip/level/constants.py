from decimal import Decimal

PAYMENT_CAP_AMOUNT = Decimal('4700.00') 
LOCK_LEVEL_NAME = 'Refer Help'
RESTRICTED_STATUS = 'Restricted'
CREDITED_STATUS = 'Credited'